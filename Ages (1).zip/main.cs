using System;

public class Example
{
   public static void Main()
   {
      int caseSwitch;
      Console.WriteLine("Press 1 to use the Ages Program, Press 2 to exit the program");
      caseSwitch = Convert.ToInt32(Console.ReadLine());
      switch (caseSwitch)
      {
          case 1:
              Console.WriteLine("How Many ages do you want to put in?: ");
              int agesInput = Convert.ToInt32(Console.ReadLine());
              Console.WriteLine("Enter your number as Integers");
              int[] amountOfAges = new int[agesInput];
              for(int index = 0; index< amountOfAges.Length; index++)
              {
                amountOfAges[index] = Convert.ToInt32(Console.In.ReadLine());
              }
              Console.Write("The ages you entered are ");
              for (int index = 0; index < amountOfAges.Length; index++)
              {
                Console.Write(amountOfAges[index] + " ");
              }
              break;
          case 2:
              Console.WriteLine("Exiting the program...");
              break;
          default:
              Console.WriteLine("Default case");
              break;
      }
   }
}