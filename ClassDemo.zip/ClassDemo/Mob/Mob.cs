﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mob
{
    public class Mob
    {
        //fields
        private string _mobName;
        private int _mobStrength;
        // Full Prperty
        public string MobName
        {
            get
            {
                return _mobName;
            }
            set
            {
                _mobName = value;
            }
        }
        public int MobStrength
        {
            get
            {
                return _mobStrength;
            }
            set
            {
                _mobStrength = value;
            }
        }

        //AutoProperty
        public int MobHealth { get; set; }
        // Constructor
        public Mob()
        {
            MobName = "";
            MobStrength = 0;
            MobHealth = 0;
        }
        public Mob(string mobName, int mobStrength, int mobHealth)
        {
            MobName = mobName;
            MobStrength = mobStrength;
            MobHealth = mobHealth;
        }

    }
}
