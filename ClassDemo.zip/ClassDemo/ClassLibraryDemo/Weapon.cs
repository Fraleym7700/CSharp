﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDemo
{
    public class Weapon
    {
        //fields
        private string _weaponName;
        private int  _weaponStrength;
        // Full Prperty
        public string WeaponName
        {
            get
            {
                return _weaponName;
            }
            set
            {
                _weaponName = value;
            }
        }
        public int WeaponStrength
        {
            get
            {
                return _weaponStrength;
            }
            set
            {
                _weaponStrength = value;
            }
        }

        //AutoProperty
        public string OriginOfWeapon { get; set; }
        // Constructor
        public Weapon()
        {
            WeaponName = "";
            WeaponStrength = 0;
            OriginOfWeapon = "";
        }
        public Weapon(string weaponName,int weaponStrength, string originOfWeapon)
        {
            WeaponName = weaponName;
            WeaponStrength = weaponStrength;
            OriginOfWeapon = originOfWeapon;
        }

    }
}
