﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDemo
{
    public class Room
    {
        //fields
        private string _roomName;
        private string _roomDescription;
        // Full Prperty
        public string RoomName
        {
            get
            {
                return _roomName;
            }
            set
            {
                _roomName = value;
            }
        }
        public string RoomDescription
        {
            get
            {
                return _roomDescription;
            }
            set
            {
                _roomDescription= value;
            }
        }

        //AutoProperty
        //none
        // Constructor
        public Room()
        {
            RoomName = "";
            RoomDescription = "";

        }
        public Room(string roomName, string roomDescription)
        {
            RoomName = roomName;
            RoomDescription = roomDescription;

        }

    }
}
