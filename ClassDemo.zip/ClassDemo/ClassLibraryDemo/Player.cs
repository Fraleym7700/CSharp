﻿using System;

namespace ClassLibraryDemo
{
    public class Player
    {
        //fields
        private string _firstName;
        private string _lastName;
        //private static int _count = 0;
        // Constructor
        public Player()
        {
            FirstName = "";
            LastName = "";
            Health = 0;
            Count++;
        }
        public Player(string firstName, string lastName, int health)
        {
            FirstName = firstName;
            LastName = lastName;
            Health = health;
            Count++;
        }
        // Full Prperty
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
        public string FullName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }
        //AutoProperty
        public int Health { get; set; }
        public static int Count { get; set; } = 0;

        // Methods
        public int DoMath()
        {
            return 4 + 5;
        }
        public int DoMath(int value1, int value2)
        {
            return value1 + value2;
        }
    }
}
