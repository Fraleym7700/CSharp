﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDemo
{
    public class Item
    {
        //fields
        private string _itemName;
        private string _itemPower;
        // Full Prperty
        public string ItemName
        {
            get
            {
                return _itemName;
            }
            set
            {
                _itemName = value;
            }
        }
        public string ItemPower
        {
            get
            {
                return _itemPower;
            }
            set
            {
                _itemPower = value;
            }
        }

        //AutoProperty
        public string OriginOfItem { get; set; }
        // Constructor
        public Item()
        {
            ItemName = "";
            ItemPower = "";
            OriginOfItem = "";
        }
        public Item(string itemName, string itemPower, string originOfItem)
        {
            ItemName = itemName;
            ItemPower = itemPower;
            OriginOfItem = originOfItem;
        }

    }
}
