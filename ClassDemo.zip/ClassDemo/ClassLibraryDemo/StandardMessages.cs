﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibraryDemo
{
   public class StandardMessages
    {
      public static string Menu()
        {
            return "1Create player\n2.Exit";
        }
        public static string ShowPlayer(Player YourPlayer)
        {
            return $"Player Name - {YourPlayer.FullName}, Health - {YourPlayer.Health}";
        }
        public static string DisplayChoiceError()
        {
            return "Not a Valid choice!";
        }
    }
}
