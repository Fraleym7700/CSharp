﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            ClassLibraryDemo.Player[] players = { new ClassLibraryDemo.Player("William", "Buckwell", 100),
                                                 new ClassLibraryDemo.Player("Michael", "Buckwell", 100),
                                                 new ClassLibraryDemo.Player("James", "Buckwell", 100)};
            List<ClassLibraryDemo.Player> players2 = new List<ClassLibraryDemo.Player>();
            do
            {
                Console.WriteLine(ClassLibraryDemo.StandardMessages.Menu());
                switch(Console.ReadLine())
                {
                    case "1":
                        //ClassLibraryDemo.Player yourPlayer = new ClassLibraryDemo.Player();
                        //yourPlayer.FirstName = "Michael";
                        //yourPlayer.LastName = "Fraley";
                        //yourPlayer.Health = 100;
                    ClassLibraryDemo.BuildPlayer.BuildaPlayer(players2);
                    Console.WriteLine(ClassLibraryDemo.StandardMessages.ShowPlayer(players[1]));
                    Console.WriteLine(ClassLibraryDemo.Player.Count);
                    break;
                    case "2":
                    exit = true;
                    break;
                    default:

                    Console.WriteLine(ClassLibraryDemo.StandardMessages.DisplayChoiceError());
                    break;
                }


                //ClassLibraryDemo.Player myPlayer = new ClassLibraryDemo.Player();

                //Console.WriteLine(myPlayer.Health);
               
                Console.ReadLine();
            } while (exit == false);
        }
    }
}
