﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoClassLibrary
{
    public class Automobile
    {
        private int _numberofWheels;
        private int _numberofDoors;
        private int _seatingspace;

        public Automobile()
        {
            NumberofWheels = 0;
            NumberofDoors = 0;
            SeatingSpace = 0;
        }
        public Automobile(int numWheels, int numDoors, int seatingSpace)
        {
            NumberofWheels = numWheels;
            NumberofDoors = numDoors;
            SeatingSpace = seatingSpace;
        }
        public int NumberofWheels { get; set; }
        public int NumberofDoors { get; set; }
        public int SeatingSpace { get; set; }
    }
}
