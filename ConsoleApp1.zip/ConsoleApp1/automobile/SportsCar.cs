﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoClassLibrary
{
    public class SportsCar : Car
    {
        private int _topspeed;
        public SportsCar(int numWheels, int numDoors, int seatingSpace, bool trunk, int topSpeed): base(numWheels, numDoors, seatingSpace, trunk)
        {
            TopSpeed = topSpeed;
        }


        public int TopSpeed { get; set; }
    }
}
