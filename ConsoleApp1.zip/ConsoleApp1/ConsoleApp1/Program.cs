﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoClassLibrary;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car mycar = new Car(4,4,4,true);
            Automobile yourCar = new Automobile();
            SportsCar thisCar = new SportsCar(4,4,2,false,250);

            Console.WriteLine(mycar.NumberofDoors);
            Console.ReadLine();
           
        }
    }
}
