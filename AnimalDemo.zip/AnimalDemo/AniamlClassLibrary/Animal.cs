﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AniamlClassLibrary
{
    public class Animal
    {
        //Fields
        //Constructors
        public Animal(string species)
        {
            Species = species;
        }
        //Propeties
        public string Species { get; set; }
        //Methods
        public virtual string MakeSound()
        {
            return "Grrrrr";
        }
    }
}
