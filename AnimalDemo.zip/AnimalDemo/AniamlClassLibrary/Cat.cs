﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AniamlClassLibrary
{
   public class Cat : Animal
    {  
        //Fields
        //Constructors
        public Cat(string species, string name) : base(species)
        {
            Species = species;
            Name = name;
        }
        //Propeties
        public string Name { get; set; }
        //Methods
        public override string MakeSound()
        {
            return "Meow";
        }
    }
}
