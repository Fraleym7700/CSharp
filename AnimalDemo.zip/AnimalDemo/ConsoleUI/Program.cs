﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AniamlClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal firstAnimal = new Animal("Basic");

            Console.WriteLine($"The Species is - {firstAnimal.Species}");
            Console.WriteLine($"It goes - {firstAnimal.MakeSound()}");

            Cat myCat = new Cat("Cat", "Socks");
            Console.WriteLine($"The Species is - {myCat.Species}");
            Console.WriteLine($"Name is - {myCat.Name}");
            Console.WriteLine($"It goes - {myCat.MakeSound()}");

            Dog myDag = new Dog("Dog", "Spike");
            Console.WriteLine($"The Species is - {myDag.Species}");
            Console.WriteLine($"Name is - {myDag.Name}");
            Console.WriteLine($"It goes - {myDag.MakeSound()}");

            List<Animal> myList = new List<Animal>();
            myList.Add(firstAnimal);
            myList.Add(myCat);
            myList.Add(myDag);

            foreach (Animal animal in myList)
            {
                Console.WriteLine($"{ animal.Species}");
            }

            Console.ReadLine();
        }
    }
}
