﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{/*
    Michael Fraley
    CSC118
    This program will calculate the distance of an object falling using the formula h=1/2 *g * T**2
    */
    class Program
    {
        const double globalVariable = 9.8;
        static void Main(string[] args)
        {
            double Time;
            Console.WriteLine("You have an object falling, Enter the amount of seconds for the time and we will calculate the distance for you: ");
            Time = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("The distance your item has fallen is -->" + FallingDistance(Time) + " meters");
            Console.ReadKey();
        }
        public static double FallingDistance(double Time)
        {
            double distance = 0.5 * globalVariable * Math.Pow(Time, 2);
            return distance;
        }
    }
}
