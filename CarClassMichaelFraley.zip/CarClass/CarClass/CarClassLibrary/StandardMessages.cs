﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
   public class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "1. Create car\n 2. Accelerate\n 3. Brake\n 4. Exit ";

        }
        public static string ShowChoiceError()
        {
            return "Not a valid Choice!";
        }
    }
}
