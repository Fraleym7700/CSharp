﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TALibrary;

namespace TextAdventure_FraleyMichael
{
    class Program
    {
                /**

                * Date 3/30/2020
                * CSC 153
                * Michael Fraley
                * This is my text adventure and it is our semester project on us developing our game.

                */
        static void Main(string[] args)
        {


            //loop condition
            bool exit = false;
            Room Woods = new Room("Woods","Dark and murky woods you can't see anything");
            Room Cave = new Room("Cave", "A dark cave, you cna't see much around, but you hear bats");
            Room Village = new Room("Village", "A village that if full with happy people");
            Room Waterfall = new Room("Waterfall", "The loud crashes of the waterfall bring peace");

            Weapon Sword = new Weapon("long sword",100, "France");
            Weapon Shuiken = new Weapon("Shuriken",75,"Japan");
            Weapon Dagger = new Weapon("Dagger",50,"Japan");
            Weapon JuJitsu = new Weapon("Jujitsu", 50, "Japan");

            Potion Healing = new Potion("Heaing Potion","Heals you up tp full life","");
            Potion Mana = new Potion("Mana Potion","Heals your mana to full","");

            Item HpCandy = new Item("Hp Candy","Level you up when you eat it", "");
            Item Chopstix = new Item("Chopstix","Use this item to eat","");
            Item Letter = new Item("Letter From your father","This is a letter from your father","");
            Item Photo = new Item("Photo of your family","Reminds you of your family back home", "");

            Mob Trader = new Mob("Trader", "NPC", "human", 50);
            Mob Fox = new Mob("Fox","NPC","Animal",25);
            Mob Pig = new Mob("Pig","NPC","Animal",25);
            Mob Salmon = new Mob("Salmon","NPC","Animal",10);

            List<Room> roomz = new List<Room>();
            List<Weapon> weapons = new List<Weapon>();
            List<Potion> potions = new List<Potion>();
            List<Item> items = new List<Item>();
            List<Mob> mobs = new List<Mob>();

            roomz.Add(Cave);
            roomz.Add(Woods);
            roomz.Add(Village);
            roomz.Add(Waterfall);

            weapons.Add(Sword);
            weapons.Add(Shuiken);
            weapons.Add(Dagger);
            weapons.Add(JuJitsu);

            potions.Add(Healing);
            potions.Add(Mana);

            items.Add(HpCandy);
            items.Add(Chopstix);
            items.Add(Letter);
            items.Add(Photo);

            mobs.Add(Trader);
            mobs.Add(Fox);
            mobs.Add(Pig);
            mobs.Add(Salmon);






            string[] rooms = new string[] { "Woods", "Cave", "Village Far Away", "Towards the Waterfall" };//Rooms
            /*string[] weapons = new string[] { "Sword", "Shuriken", "Dagger", "JuJitsu" };//Rooms
            string[] potion = new string[] { "Healing", "Mana", };
            List<string> items = new List<string>() { "HP candy", "Chopstix", "Letter from your father", "Picture of your family" };//Items
            List<string> mobs = new List<string>() { "Wandering Trader", "Fox", "Pig", "Salmon" };//Monsters
            */
            /*foreach (var car in cars)
            {
                Console.WriteLine($"{car.Make} {car.Year} );

            }*/
            do
            {
                //Display main menu for the users choices
                Console.WriteLine("1.) Display Rooms");
                Console.WriteLine("2.) Display Weapons");
                Console.WriteLine("3.) Display potion");
                Console.WriteLine("4.) Display Items");
                Console.WriteLine("5,) Display Mob");
                Console.WriteLine("6.) Play Game");
                Console.WriteLine("7.) Exit");
                Console.WriteLine();
                Console.WriteLine("Enter Choice: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        DisplayItem.displayArray(rooms);//Refer to the Display Room Function
                        break;
                    case "2":
                        foreach (var wep in weapons)
                        {
                            Console.WriteLine($"{wep.WeaponName} {wep.WeaponStrength} {wep.OriginOfWeapon} ");
                        }//Refer to the Display Weapon Function
                            break;
                    case "3":
                        foreach (var x in potions )
                        {
                            Console.WriteLine($"{x.ItemName} {x.ItemPower} {x.OriginOfItem} ");
                        } //Refer to the display potion function
                        break;
                    case "4":
                        foreach (var x in items)
                        {
                            Console.WriteLine($"{x.ItemName} {x.ItemPower} {x.OriginOfItem} ");
                        }; // Refer to the Display item function
                        break;
                    case "5":
                        foreach (var x in mobs)
                        {
                            Console.WriteLine($"{x.FirstName} {x.Class} {x.Race} {x.Health} ");
                        };// Refer to the display mob funtion
                        break;
                    case "6":
                        PlayGame.playGame(rooms);
                        break;
                    case "7":
                        Console.WriteLine("Exiting the program"); //Allow user to exit
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid entry. Please reenter choice: ");
                            Console.Clear();
                            break;
                        } //end default
                }//end switch
            } while (exit == false);//end while
        }// ends public static void

    }// ends class
}// ends namespace
