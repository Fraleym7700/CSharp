﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALibrary
{
   public class DisplayItem
    {
        public static void displayArray(string[] Input)
        {

            for (int i = 0; i < Input.Length; i++)
            {
                Console.WriteLine(Input[i] + " ");
            }
            Console.WriteLine("");
        }


        public static void displayList(List<string> Input)
        {

            for (int i = 0; i < Input.Count(); i++)
            {
                Console.WriteLine($"{Input[i]}");
            }
            Console.WriteLine("");
        }
    }
}
