﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALibrary
{
   public class PlayGame
   {
        public static void playGame(string[] rooms)
        {
            bool exit = false;
            int roomNum = 0;
            List<Player> MyPlayer = new List<Player>();
           
            
            Console.WriteLine(StandardMessages.Menu());
 
            CreateAPlayer.BuildaPlayer(MyPlayer);
            Console.WriteLine(StandardMessages.ShowPlayer(MyPlayer[0]));
            Console.WriteLine(Player.Count);

        do
        {
            //Display main menu for the users choices
            Console.WriteLine("1.) Move North");
            Console.WriteLine("2.) Move South");
            Console.WriteLine("3.) Attack");
            Console.WriteLine("4.) Exit");
            Console.WriteLine("");
            Console.WriteLine($"You are in {rooms[roomNum]}");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    moveNorth(rooms, ref roomNum);//Refer to the Display Room Function
                    break;
                case "2":
                    moveSouth(rooms, ref roomNum);//Refer to the Display Weapon Function
                    break;
                case "3":
                    Attack(); //Refer to the display potion function
                    break;
                case "4":
                    Console.WriteLine("Exiting the program"); //Allow user to exit
                    break;
                default:
                    {
                        Console.WriteLine("Invalid entry. Please reenter choice: ");
                        Console.Clear();
                        playGame(rooms);
                        break;
                    } //end default
            }//end switch
        } while (exit == false);//end while
   }

        public static void moveNorth(string[] rooms, ref int roomNum)
        {

            if (roomNum != 3)
            {
                roomNum++;
                Console.WriteLine(rooms[roomNum]);
            }
            else
            {
                Console.WriteLine("You went to far");
                Console.ReadLine();
            }

        }

        public static void moveSouth(string[] rooms, ref int roomNum)
        {
            if (roomNum != -1)
            {
                roomNum--;
                Console.WriteLine(rooms[roomNum]);
            }
            else
            {
                Console.WriteLine("You went to far");
                Console.ReadLine();
            }
        }
        public static void  Attack()
        {
            Random number = new Random();
            int value = number.Next(0,2000);
            if (value >= 1500)
                Console.WriteLine("Attack did large damagae");
            else if (value >= 1000)
                Console.WriteLine("Attack landed with minimal damage");
            else
                Console.WriteLine("Attack Missed");

        }
    }
}
