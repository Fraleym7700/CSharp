﻿using System;

namespace TALibrary
{
    public class Player
    {
        //fields
        private string _firstName;
        private string _lastName;
        private string _password;
        private string _class;
        private string _race;

        //private static int _count = 0;
        // Constructor
        public Player()
        {
            FirstName = "";
            Class = "";
            Race = "";
            Health = 0;
            Password = "";
        }
        public Player(string firstName, string classofplayer, string race, int health)
        {
            FirstName = firstName;
            Class = classofplayer;
            Race = race;
            Health = health;
        }
        public Player(string firstName, string classofplayer, string race, int health, string password)
        {
            FirstName = firstName;
            Class = classofplayer ;
            Race = race;
            Health = health;
            Password = password;
        }
        // Full Prperty
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
        public string Class
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }
        //AutoProperty
        public int Health { get; set; }
        public static int Count { get; set; } = 0;

        // Methods
        
    }
}
