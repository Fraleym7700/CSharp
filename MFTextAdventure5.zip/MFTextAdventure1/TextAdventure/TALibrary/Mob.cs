﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALibrary
{
    public class Mob : Player
    {
        //fields
        private int _mobStrength;
        // Full Prperty

        public int MobStrength
        {
            get
            {
                return _mobStrength;
            }
            set
            {
                _mobStrength = value;
            }
        }

        //AutoProperty
        public int MobHealth { get; set; }
        // Constructor
        public Mob(string firstName, string classofplayer, string race, int health) : base(firstName, classofplayer, race, health)
        {
            
            MobStrength = 0;
        }
        public Mob(int mobStrength) : base()
        {
           
            MobStrength = mobStrength;
           
        }

    }
}
