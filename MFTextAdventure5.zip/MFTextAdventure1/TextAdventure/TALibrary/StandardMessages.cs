﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TALibrary
{
    public class StandardMessages
    {
        public static string Menu()
        { 
            return "Create your player";
        }
        public static string ShowPlayer(Player YourPlayer)
        {
            return $"Player Name - {YourPlayer.FirstName}, LastName - {YourPlayer.LastName}, Health - {YourPlayer.Health}, Class - {YourPlayer.Class}, Race - {YourPlayer.Race}";
        }
        public static string DisplayChoiceError()
        {
            return "Not a Valid choice!";
        }
    }
}
