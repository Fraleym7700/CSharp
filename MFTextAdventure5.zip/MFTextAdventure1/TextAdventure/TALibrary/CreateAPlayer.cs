﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALibrary
{
    class CreateAPlayer
    {
        public static void BuildaPlayer(List<Player> inputList)
        {
            Player thisPlayer = new Player();
            bool error = false;


            do
            {

                Console.WriteLine("What is the player first name?");
                Console.Write("=>");
                thisPlayer.FirstName = Console.ReadLine();
                Console.WriteLine("What ia the players last name?");
                Console.WriteLine("=>");
                thisPlayer.LastName = Console.ReadLine();
                Console.WriteLine("What is the players health?");
                Console.WriteLine("=>");
                thisPlayer.Health = ConvertToInt(Console.ReadLine());
                Console.WriteLine("What is the players password?");
                Console.WriteLine("=>");
                thisPlayer.Password = Console.ReadLine();
                Console.WriteLine("What is the players Class?");
                Console.WriteLine("=>");
                thisPlayer.Class = Console.ReadLine();
                Console.WriteLine("What is the players Race?");
                Console.WriteLine("=>");
                thisPlayer.Race = Console.ReadLine();
                if (thisPlayer.Health < 0)
                {
                    error = true;
                    Console.WriteLine("Something went wrong");
                }
                else
                {
                    error = false;
                }
            } while (error == true);
            inputList.Add(thisPlayer);

        }
        public static int ConvertToInt(string input)
        {
            int output = 0;
            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
