﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TALibrary
{
  public class Potion : Item
    {
        public Potion() : base()
        {

        }

        public Potion(string itemName, string itemPower, string originOfItem) : base(itemName, itemPower, originOfItem)
        {

        }
    }
}
