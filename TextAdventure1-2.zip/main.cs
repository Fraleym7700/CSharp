using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure_FraleyMichael
{
    class Program
    {
        static void Main(string[] args)
        {
          displayMenu();



        }//end main




        public static void displayMenu()
        {
            
            //loop condition
            bool exit = false;
            while (exit == false)
            { 
              //Display main menu for the users choices
            Console.WriteLine("Display Rooms");
            Console.WriteLine("Display Weapons");
            Console.WriteLine("Display potion");
            Console.WriteLine("Display Items");
            Console.WriteLine("Display Mob");
            Console.WriteLine("Exit");
            Console.WriteLine();
            Console.WriteLine("Enter Choice: ");

                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        displayRooms();//Refer to the Display Room Function
                        break;
                    case "2":
                        displayWeapons();//Refer to the Display Weapon Function
                        break;
                    case "3":
                        displayPotions(); //Refer to the display potion function
                        break;
                    case "4":
                        displayItem(); // Refer to the Display item function
                        break;
                    case "5":
                        displayMob();// Refer to the display mob funtion
                        break;
                    case "6":
                        exit == true; //Allow user to exit
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid entry. Please reenter choice: ");
                            Console.Clear();
                            displayMenu();
                            break;
                        } //end default
                }//end switch
            }//end while
        }// ends public static void






        public static void displayRooms(){
        string[] rooms = new string[] { "Woods", "Cave", "Village Far Away", "Towards the Waterfall" };//Rooms
        Console.WriteLine(string.join)(" ", rooms);
        }
        
       public static void displayWeapons(){
        string[] weapons = new string[] { "Sword", "Shuriken", "Dagger", "JuJitsu"};//Rooms
        Console.WriteLine(string.join)(" ", weapons);
        }

        public static void displayPotions(){
        string[] potion = new string[] { "Healing", "Mana", };
        Console.WriteLine(string.join)(" ", potion);
        }

        public static void displayItem(){
        List<string> items = new List<string>() { "HP candy", "Chopstix", "Letter from your father", "Picture of your family" };//Items
        Console.WriteLine(string.join)(" ", item);
        }

        public static void displayMob(){
       List<string> mobs = new List<string>() { "Wandering Trader", "Fox", "Pig", "Salmon" };//Monsters
        Console.WriteLine(string.join)(" ", mobs);
        }
      







    }// ends class
}// ends namespace

