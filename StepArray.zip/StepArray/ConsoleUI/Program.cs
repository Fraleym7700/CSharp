﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string[] names = new string[] {"Tom", "Mike", "Thor", "William", "Bob", "James", "Yes", "Keep going", "Don't Stop" };
            int index = 0;


            do
            {
                if(index < names.Length && index >= 0)
                {
                    Console.WriteLine($"Current name is - {names[index]}");
                }
                
                Console.WriteLine(DemoLibrary.StandardMessages.DisplayMenu());
                string input = Console.ReadLine();

                switch(input)
                {
                    case "1":
                       
                        DisplayNextName(names, ref index);
                        break;

                    case "2":
                        DisplayLastName(names, ref index);
                        break;
                }
            } while (exit == false);
        }

        private static void DisplayLastName(string[] names, ref int index)
        {
            if (index > 0)
            {
                index--;
                Console.WriteLine(names[index]);
                
            }
            else
            {
                Console.WriteLine("No More Names!");
            }
        }

        private static void DisplayNextName(string[] names, ref int index)
        {
            if (index < names.Length)
            {
                if (index != names.Length - 1)
                {
                    index++;
                }
                else
                {
                    Console.WriteLine("No More Names!");
                }
              
            }
           
        }
    }
}
