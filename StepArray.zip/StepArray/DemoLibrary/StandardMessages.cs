﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Show Next Name \n2. Show Last Name\n3. Exit";
        }
    }
}
