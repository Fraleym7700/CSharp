﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLib
{
    public class Carclass
    {
        private string _year;
        private string _make;
        private int _speed;
        //constructor
        public Carclass()
        {
            Year = "";
            Make = "";
            Speed = 0;

        }
        public Carclass(string year, string make, int speed)
        {
            Year = year;
            Make = make;
            Speed = speed;
        }
        public string Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }

        }
        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }

        }
        public int Speed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }

        }
    }
}
