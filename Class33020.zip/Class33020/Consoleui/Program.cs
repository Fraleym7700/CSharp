﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLib;

namespace Consoleui
{
    class Program
    {
        static void Main(string[] args)
        {
            Carclass[] cars2 = new Carclass[5];
            // Carclass cars2 = { new Car(),.......)
            List<Carclass> cars = new List<Carclass>() new Carclass("1996", "Ford, 10");

            cars[0].Year = "1999";
            Carclass myCar = new Carclass("1980", "Chevy", 25);
            cars.Add(myCar);
            cars.Add(new Carclass("1989", "Dodge", 25));

            cars2[0] = new Carclass("1980", "Chevy", 25);

            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Make} {car.Year} );

            }
            Console.ReadLine();


     
        }
    }
}
