﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerLibrary;

namespace ConsoleUI
{
    class Program
    {/*This program will take the customers information in the Customerinfo.txt file and determien where or not they qualify for the discound depending on how much money they spend.
        If they spend 500 dollers they will recieve 5% off, if they spend 1000 they will receive 6% off, if they spend 1,500 they will recieve 7% off, and if they spend 2000 they will recieve 10% off.
        Then the informtion will be updated and created into CustomerInfo2.txt applying the discount to their purchases.*/
        static void Main(string[] args)
        {
            do
            {
                DataOperations.GetData();
                var custIndex = DataOperations.GetID();
                DataOperations.DisplayMenu();

                if (DataOperations.UserChoice() == "1")
                    Console.WriteLine(DataOperations.preferredCustomers[custIndex].ToString());
                else
                    DataOperations.UpdateData();
            } while (true);
        }
    }
}
