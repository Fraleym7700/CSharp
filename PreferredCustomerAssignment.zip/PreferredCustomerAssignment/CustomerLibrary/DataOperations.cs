﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
    public static class DataOperations
    {
        //array of prefreed customer
        public static PreferredCustomer[] preferredCustomers;
        //id the user enters as input
        

        public static void GetData()
        {
            //read from the text file
            using (var reader = new StreamReader("CustomerInfo.txt"))
            {
                var index = 0;
                preferredCustomers = new PreferredCustomer[5];
                while (!reader.EndOfStream)
                {
                    //get the line from the text file into an array
                    var line = reader.ReadLine().Split(':');
                    var name = line[0];
                    var address = line[1];
                    var phone = line[2];
                    var id = line[3];
                    var email = line[4];
                    var spentAmount = Convert.ToInt32(line[5]);
                    var onEmailList = Convert.ToBoolean(line[6]);
                    preferredCustomers[index] = new PreferredCustomer(name, address, phone, id, email, spentAmount, onEmailList);
                    index++;
                }
            }
        }

        public static void UpdateData()
        {
            //read from the text file
            using (var writer = new StreamWriter("CustomerInfo2.txt"))
            {
                for (var i = 0; i < 5; i++)
                {
                    var name = preferredCustomers[i].CustomerName;
                    var address = preferredCustomers[i].Address;
                    var phone = preferredCustomers[i].Phone;
                    var id = preferredCustomers[i].CustomerID;
                    var email = preferredCustomers[i].CustomerEmail;
                    var updattedSpentAmount = preferredCustomers[i].CalcAmount();
                    var onEmailList = preferredCustomers[i].OnEmailList;
                    writer.WriteLine($"{name}:{address}:{phone}:{id}:{email}:{updattedSpentAmount}:{onEmailList}");
                }

            }
        }

        //get customer id and compare it to existing customer ids
        public static int GetID()
        {
            string enteredID = "";
            do
            {
                var customerIndex = 0;
                Console.Write("Please enter user ID: ");
                enteredID = Console.ReadLine();

                foreach (var id in preferredCustomers)
                {
                    if (id.CustomerID == enteredID)
                    {
                        return customerIndex;
                    }
                    else
                    {
                        customerIndex++;
                    }
                }
                Console.Write("ID does not exist");
            } while (true);
        }
        //get user input. only opton 1 and 2 are accepted
        public static string UserChoice()
        {
            var userChoice = Console.ReadLine();
            while(userChoice != "1" && userChoice != "2")
            {
                Console.WriteLine("Wrong entry. Try againg.");
                DisplayMenu();
                userChoice = Console.ReadLine();
            }

            return userChoice;
        }
        //display user menu
        public static void DisplayMenu()
        {
            Console.WriteLine("1. Display Customer Information");
            Console.WriteLine("2. Update Customer Inforation");
            Console.Write("Please enter your choice: ");
        }

    }
}
