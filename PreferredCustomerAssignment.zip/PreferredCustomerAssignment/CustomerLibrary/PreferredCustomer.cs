﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
    public class PreferredCustomer : Customer
    {
        public PreferredCustomer(string name, string address, string phone, string id, string email, int spentAmount, bool onmailList)
            :base(name, address, phone, id, email, spentAmount, onmailList)
        {
            DiscountLevel = SetDiscountLevel();

        }
        public readonly decimal DiscountLevel;

        //calculate discount percentage
        public decimal SetDiscountLevel()
        {
            int range = SpentAmount / 500;
            switch (range)
            {
                case 0:
                    return 0;
                    break;
                case 1:
                    return 0.05m;
                    break;
                case 2:
                    return 0.06m;
                    break;
                case 3:
                    return 0.07m;
                    break;
                default:
                    return 0.01m;
                    break;
            }
        }
        public double GetDiscount()
        {
            return SpentAmount * (double)DiscountLevel;
        }

        public override double CalcAmount()
        {
            return base.CalcAmount() - GetDiscount();
        }

        public override string ToString()
        {
            return String.Format($"CustomerID: {CustomerID}\nCustomr Name: {CustomerName}\nCustomer Address: {Address}\nCustomer Phone: {Phone}\nCustomerEmail:{CustomerEmail}\nCustomer Spending: {SpentAmount}\n Customer on Email List{OnEmailList} ");
        }
    }
}
