﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
   public class Customer : Person
    {
        public Customer(string name, string address, string phone, string id, string email, int spentAmount, bool onemailList)
            :base(name, address, phone)
        {
            CustomerID = id;
            CustomerEmail = email;
            SpentAmount = spentAmount;
            OnEmailList = onemailList;
        }
        public string CustomerID { get; set; }
        public string CustomerEmail { get; set; }
        public int SpentAmount { get; set; }
        public bool OnEmailList { get; set; }

        public virtual double CalcAmount()
        {
            return SpentAmount;
        }
    }
    
}
