﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1.Enter employee's name\n" +
                    "2. Enter employee's phone number\n" +
                    "3. Enter employee's age.\n" +
                    "4 Displaye employee information\n" +
                    "5. Display average age of employees.\n" +
                    "6. Exit";
        }

        public static string PromptForName()
        {
            return "Enter employees name -> " ;
        }

        public static string PromptForNumber()
        {
            return " Enter employees phone number -->";
        }
        public static string PromptForAge()
        {
            return "Enter employee's age --->";
        }

        public static string DisplayNumberError()
        {
            return "Not a valid number!";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return$"Employee name = {name[index]}" +
                $"Employee Phone = { phone[index] }" +
                $"Employee Age = {age[index]}";
        }
    }

}
