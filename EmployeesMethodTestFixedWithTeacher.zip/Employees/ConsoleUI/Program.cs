﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Michael Fraley
 * CSC 153
 */
namespace ConsoleUI
{
    class Program
    {
        

        static void Main(string[] args)
        {
            //Create input var for user input and sentry loop
            string input;
            bool exit = false;
            // create my constant Var
            const int SIZE = 5;
            int nameIndex = 0, phoneIndex = 0;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                input = Console.ReadLine();
                // Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForName());
                        input = Console.ReadLine();

                        EnterName(ref employeeNames, ref nameIndex, input);
                        break;
                    case "2":
                        Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForNumber());
                        input = Console.ReadLine();
                        EnterPhone(ref employeePhone, ref phoneIndex, input);
                        break;
                    case "3":
                        
                        Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForAge());
                        input = Console.ReadLine();
                        employeeAge = EnterAge(employeeAge, input);
                        break;
                    case "4":
                        DisplayEmpInfoToUser(employeeNames, employeePhone, employeeAge);
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice!");
                        break;


                }


            } while (exit == false);

        }


        public static void EnterName(ref string[] name, ref int index, string input)
        {
            name[index] = input;
            index++;
            Console.WriteLine("");

        }
        public static void EnterPhone(ref string[] phone, ref int index, string input)
        {
            phone[index] = input;
            index++;
            Console.WriteLine("");

        }
        public static List<int> EnterAge(List<int> empAge, string input)
        {
            int number = 0;
            List<int> age = new List<int>();
            age = empAge;
            if (int.TryParse(input, out number))
            {
                age.Add(number);
            }
            else
            {
                EmployeeLibrary.StandardMessages.DisplayNumberError();
            }
            Console.WriteLine("");
            return age;
        }
        public static void DisplayEmpInfoToUser(string[] name, string[] phone, List<int> age)
        {
            for (int index = 0; index < age.Count; index++)
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee(name, phone, age, index));
            }

        }
    }

}
