﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UMLClassLibrary
{
    class Creature
    {
        //Field
        private string _name;
        private string _description;
        private int _ac;
        private int _hitPoints;

        //Constructor
        public Creature()
        {
            Name = "No Name";
            Description = "No Description";
            AC = 0;
            HitPoints = 0;
            Mana = 0;
        }
        public Creature(string name, string description, int ac, int hp, int mana)
        {
            Name = name;
            Description = description;
            AC = ac;
            HitPoints = hp;
            Mana = mana;
        }
        //Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public int AC
        {
            get
            {
                return _ac;
            }
            set
            {
                _ac = value;
            }
        }
        public int HitPoints
        {
            get
            {
                return _hitPoints;
            }
            set
            {
                _hitPoints = value;
            }
        }
        public int Mana { get; set; }


        //Methods
        public static void RegenerateMana()
        {
            //TODO Create Code to RegenMANA
        }
        public static string LookRoom(Room inputRoom)
        {
            //TODO Create code to Looj=k

            return inputRoom.Description;

        }
    }
}
