﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure
{
    class PlayGame
    {
        public static void playGame(string[] rooms)
        {
            bool exit = false;
            int roomNum = 0;
            do
            {
                //Display main menu for the users choices

                Console.WriteLine("1.) Move North");
                Console.WriteLine("2.) Move South");
                Console.WriteLine("3.) Attack");
                Console.WriteLine("5.) Exit");
                Console.WriteLine("");
                Console.WriteLine($"You are in {rooms[roomNum]}");

                int choice = Convert.ToInt32(Console.In.ReadLine());

                switch (choice)
                {
                    case 1:
                        moveNorth(rooms, ref roomNum);//Refer to the Display Room Function
                        break;
                    case 2:
                        moveSouth(rooms, roomNum);//Refer to the Display Weapon Function
                        break;
                    case 3:
                        Attack(20); //Refer to the display potion function
                        break;
                    case 7:
                        Console.WriteLine("Exiting the program"); //Allow user to exit
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid entry. Please reenter choice: ");
                            Console.Clear();
                            playGame(rooms);
                            break;
                        } //end default
                }//end switch
            } while (exit == false);//end while
        }// ends public static void

        public static void moveNorth(string[] rooms, ref int roomNum)
        {

            if (roomNum != 3)
            {
                roomNum++;
                Console.WriteLine(rooms[roomNum]);
            }
            else
            {
                Console.WriteLine("You went to far");
                Console.ReadLine();
            }

        }

        public static void moveSouth(string[] rooms, int roomNum)
        {
            if (roomNum != -1)
            {
                roomNum--;
                Console.WriteLine(rooms[roomNum]);
            }
            else
            {
                Console.WriteLine("You went to far");
                Console.ReadLine();
            }
        }
        public static void Attack(int number)
        {
            if (number >= 20)
                Console.WriteLine("Attack did large damagae");
            else if (number >= 10)
                Console.WriteLine("Attack landed with minimal damage");
            else
                Console.WriteLine("Attack Missed");

        }
    }
}
