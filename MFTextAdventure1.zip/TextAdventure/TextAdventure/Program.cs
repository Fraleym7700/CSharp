﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure_FraleyMichael
{
    class Program
    {
        static void Main(string[] args)
        {
            
  
            //loop condition
            bool exit = false;
            string[] rooms = new string[] { "Woods", "Cave", "Village Far Away", "Towards the Waterfall" };//Rooms
            string[] weapons = new string[] { "Sword", "Shuriken", "Dagger", "JuJitsu" };//Rooms
            string[] potion = new string[] { "Healing", "Mana", };
            List<string> items = new List<string>() { "HP candy", "Chopstix", "Letter from your father", "Picture of your family" };//Items
            List<string> mobs = new List<string>() { "Wandering Trader", "Fox", "Pig", "Salmon" };//Monsters

            do
            {
                //Display main menu for the users choices
                Console.WriteLine("1.) Display Rooms");
                Console.WriteLine("2.) Display Weapons");
                Console.WriteLine("3.) Display potion");
                Console.WriteLine("4.) Display Items");
                Console.WriteLine("5,) Display Mob");
                Console.WriteLine("6.) Play Game");
                Console.WriteLine("7.) Exit");
                Console.WriteLine();
                Console.WriteLine("Enter Choice: ");

                int choice = Convert.ToInt32(Console.In.ReadLine());

                switch (choice)
                {
                    case 1:
                        TextAdventure.DisplayItems.displayArray(rooms);//Refer to the Display Room Function
                        break;
                    case 2:
                        TextAdventure.DisplayItems.displayArray(weapons);//Refer to the Display Weapon Function
                        break;
                    case 3:
                        TextAdventure.DisplayItems.displayArray(potion); //Refer to the display potion function
                        break;
                    case 4:
                        TextAdventure.DisplayItems.displayList(items); // Refer to the Display item function
                        break;
                    case 5:
                        TextAdventure.DisplayItems.displayList(mobs);// Refer to the display mob funtion
                        break;
                    case 6:
                        TextAdventure.PlayGame.playGame(rooms);
                        break;
                    case 7:
                        Console.WriteLine("Exiting the program"); //Allow user to exit
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid entry. Please reenter choice: ");
                            Console.Clear();
                            break;
                        } //end default
                }//end switch
            } while (exit == false);//end while
        }// ends public static void

    }// ends class
}// ends namespace
