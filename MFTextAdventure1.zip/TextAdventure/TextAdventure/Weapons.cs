﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure
{
    class Weapons
    {
        public int weakSword(string name, int attack) 
        {
            if 
        }
    }
}
