﻿using System;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("After the markup, the total value is --> $" + CalculateRetail());
        }
        public static double CalculateRetail()
        {

            double retailPrice;
            double wholesale;
            double markup;
            Console.WriteLine("Enter the value of the item");
            wholesale = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the markup percentage you would like to enter");
            markup = Convert.ToDouble(Console.ReadLine());
            double markupPercent = markup / 100;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;

        }
    }
}
