﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * 
             * 
             The application should create a list of three RetailItem objects containing the following data:

            Description, Units on Hand, Price
            Jacket, 12, $59.05
            Jeans, 40, $34.95
            Shirt, 20, $24.95
            The application should loop through the list, displaying each element's property in a readable format.
            */


            RetailItemLib.RetailItem Jacket = new RetailItemLib.RetailItem("Jacket", 12, 59.05);
            RetailItemLib.RetailItem Jeans = new RetailItemLib.RetailItem("Jeans", 40, 34.95);
            RetailItemLib.RetailItem Shirt = new RetailItemLib.RetailItem("Shirt", 20, 24.95);
            Type type = typeof(RetailItemLib.RetailItem);
            PropertyInfo[] properties = type.GetProperties();
            Console.WriteLine("Item one");
            Console.ReadLine();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine("{0} = {1}", property.Name, property.GetValue(Jacket, null));
            }

            Console.ReadLine();
            Console.WriteLine("Item two");
            Console.ReadLine();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine("{0} = {1}", property.Name, property.GetValue(Jeans, null));
            }
            Console.ReadLine();
            Console.WriteLine("Item three");
            Console.ReadLine();
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine("{0} = {1}", property.Name, property.GetValue(Shirt, null));
            }


            Console.ReadLine();



        }
    }
}
