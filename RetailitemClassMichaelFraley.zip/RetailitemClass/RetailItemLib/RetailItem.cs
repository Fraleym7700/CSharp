﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemLib
{
    public class RetailItem
    {
        private string _description;
        private int _unitOnHand;
        private double _price;
        

        public RetailItem(string description, int unitOnHand, double price)
        {
            Description = description;
            UnitOnHand = unitOnHand;
            Price = price;
            
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }

        }
        
        public int UnitOnHand
        {
            get
            {
                return _unitOnHand;
            }
            set
            {
                _unitOnHand = value;
            }
        }

        public double Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
        //methods

    }
}
