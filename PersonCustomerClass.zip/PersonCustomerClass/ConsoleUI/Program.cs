﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerLibrary;
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> People = new List<Person>();
            List<Customer> Cust = new List<Customer>();

            Person a = new Person();
            a.Name = "Bob";
            a.Address = "New Carmichael Street";
            a.TelephoneNumber = "910-559-8822";

            Customer b = new Customer();
            b.Name = "Jill";
            b.Address = "8829 Goldfish Street";
            b.TelephoneNumber = "910-889-59244";
            b.OnMailingList = true;
            b.CustomerNumber = "593a345t29";

            People.Add(a);
            People.Add(b);
            Cust.Add(b);

            Console.WriteLine("List of people and customer under Person List");
            Console.WriteLine("------------------------------------------------");
            foreach (var customer in People)
            {
                Console.WriteLine($"{customer.Name} {customer.Address} {customer.TelephoneNumber}");
            }
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine("List of customers under Customer List");
            Console.WriteLine("------------------------------------------------");

            foreach (var customer in Cust)
            {
                Console.WriteLine($"{customer.Name} {customer.Address} {customer.TelephoneNumber} {customer.CustomerNumber} {customer.OnMailingList} ");
            }
            Console.WriteLine("------------------------------------------------");
            Console.ReadLine();
        }
    }
}
