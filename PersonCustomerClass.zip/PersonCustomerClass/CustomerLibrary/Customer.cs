﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerLibrary
{
    public class Customer : Person
    {
        private string _customerNumber;
        private bool _onMailingList;
        
        public Customer()
        {
            Name = "";
            Address = "";
            TelephoneNumber = "";
            CustomerNumber = "";
            OnMailingList = false;

        }

        public Customer(string name, string address, string telephonenumber) : base(name,address,telephonenumber)
        {
            CustomerNumber = "";
            OnMailingList = false;

        }
        public Customer(string name, string address, string telephonenumber, string customerNumber, bool onMailingList) : base(name,address,telephonenumber)
        {
            CustomerNumber = customerNumber;
            OnMailingList = false;

        }
        public string CustomerNumber
        {
            get
            {
                return _customerNumber;
            }
            set
            {
                _customerNumber = value;
            }
        }
        public bool OnMailingList
        {
            get
            {
                return _onMailingList;
            }
            set
            {
                _onMailingList = value;
            }
        }
    }
}
